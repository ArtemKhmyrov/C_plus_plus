#include "MyForm.h"
#include <array>

using namespace System;
using namespace System::Windows::Forms;
[STAThreadAttribute]
void Main(cli::array<System::String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	electrictrain::MyForm form;
	Application::Run(% form);
}
