#pragma once
#include <iostream>
#include "Header.h"

using namespace std;

//����� ����� ����� ��� ������ � ��� �� ������� �������� ��� ������
class train 
{
private:
	vector <slovo> poezd;
public:

	void SetCh(int a, int b){
		poezd[a].Setch(b);
	}

	void SetCh2(int a, int b){
		poezd[a].Setch2(b);
	}

	void SetMin(int a, int b){
		poezd[a].Setmin(b);
	}

	void SetMin2(int a, int b){
		poezd[a].Setmin2(b);
	}

	void setfl(int a, bool b)
	{
		poezd[a].Setfl(b);
	}

	bool getfl(int a)
	{
		return poezd[a].Getfl();
	}

	void setpb(slovo a){
		poezd.push_back(a);
	}

	void CL(){
		poezd.clear();
	}

	int retsize() 
	{
		return poezd.size();
	}
	string reta(int a) 
	{
		return poezd[a].Geta();
	}
	string retb(int a) 
	{
		return poezd[a].Getb();
	}
	string retpromezh(int a)
	{
		return poezd[a].Getpromezh();
	}
	int retch(int a)
	{
		return poezd[a].GetCh();
	}
	int retmin(int a)
	{
	return poezd[a].Getmin();
	}
	int retch2(int a)
	{
		return poezd[a].GetCh2();
	}
	int retmin2(int a)
	{
	return poezd[a].Getmin2();
	}

};

train MV;
